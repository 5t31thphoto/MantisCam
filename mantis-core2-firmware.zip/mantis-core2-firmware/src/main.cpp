/*
 * ============================================================
 *  MANTIS Core2 — Elegant Praying-Mantis Companion Firmware
 *  for M5Stack Core2  ↔  ESP32-CAM (SoftAP at 192.168.5.1)
 * ============================================================
 *  Navigation (capacitive buttons):
 *      BtnA (left)  = previous screen / back
 *      BtnB (middle)= select / confirm
 *      BtnC (right) = next screen / forward
 *
 *  Default CAM hotspot:  Mantis_1_Hotspot / mantis33
 *  Stream:               http://192.168.5.1:8081/stream
 *  Snapshot:             http://192.168.5.1/snapshot
 *  Control:              http://192.168.5.1/control?var=…&val=…
 *  Status / Config:      http://192.168.5.1/status  /config
 */

#include <M5Unified.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <JPEGDEC.h>

// -------------------- theme palette (mantis) --------------------
static const uint16_t COL_BG       = 0x0A20;   // deep forest
static const uint16_t COL_PANEL    = 0x1A40;
static const uint16_t COL_ACCENT   = 0x5FE0;   // leaf green
static const uint16_t COL_TEXT     = 0xE7FF;
static const uint16_t COL_DIM      = 0x7BEF;
static const uint16_t COL_ALERT    = 0xF800;
static const uint16_t COL_OK       = 0x07E0;
static const uint16_t COL_BTN      = 0x2A60;
static const uint16_t COL_BTN_HI   = 0x3C80;

// -------------------- screens --------------------
enum Screen : uint8_t {
  SCR_HOME = 0,
  SCR_STREAM,
  SCR_SNAPSHOT,
  SCR_CAMCTRL,
  SCR_WIFI,
  SCR_STATUS,
  SCR_COUNT
};
static const char *SCR_NAMES[] = {
  "Home", "Live Stream", "Snapshot", "Camera Ctrl", "WiFi Setup", "Status"
};

// -------------------- persistent config --------------------
Preferences prefs;
String cfgSsid   = "Mantis_1_Hotspot";
String cfgPass   = "mantis33";
String cfgCamIp  = "192.168.5.1";
String cfgAdmin  = "admin1234";          // matches manager default style

// -------------------- runtime state --------------------
Screen  g_screen     = SCR_HOME;
bool    g_wifiOk     = false;
bool    g_streaming  = false;
bool    g_needRedraw = true;
uint32_t g_lastBtnMs = 0;
JPEGDEC  jpeg;
uint8_t *g_jpgBuf    = nullptr;
size_t   g_jpgCap    = 80 * 1024;        // generous buffer in PSRAM
size_t   g_jpgLen    = 0;

// simple on-screen keyboard state
bool     g_oskActive = false;
String  *g_oskTarget = nullptr;          // points to the string being edited
String   g_oskTitle  = "";
char     g_oskBuf[64] = {0};
int      g_oskCursor = 0;
bool     g_oskShift  = false;

// camera control mirrors (loaded from /controls when possible)
int  g_quality   = 12;
int  g_framesize = 8;   // VGA
int  g_bright    = 0;
int  g_contrast  = 0;
int  g_sat       = 0;
int  g_led       = 0;
bool g_hmirror   = false;
bool g_vflip     = false;

// -------------------- forward decls --------------------
void loadConfig();
void saveConfig();
void connectWifi();
void drawHeader(const char *title);
void drawFooter();
void drawHome();
void drawStream();
void drawSnapshot();
void drawCamCtrl();
void drawWifi();
void drawStatus();
void drawOsk();
void handleButtons();
void handleTouch();
bool httpGetJson(const String &path, JsonDocument &doc);
bool httpControl(const char *var, int val);
bool httpControlStr(const char *var, const char *val);
bool fetchSnapshot();
void startStreamLoop();
void stopStream();
int  jpegDrawCallback(JPEGDRAW *pDraw);

// ============================================================
void setup() {
  auto cfg = M5.config();
  cfg.serial_baudrate = 115200;
  M5.begin(cfg);
  M5.Display.setRotation(1);          // landscape 320×240
  M5.Display.setBrightness(180);
  M5.Display.fillScreen(COL_BG);

  // allocate JPEG buffer in PSRAM if available
  if (psramFound()) {
    g_jpgBuf = (uint8_t *)ps_malloc(g_jpgCap);
  }
  if (!g_jpgBuf) {
    g_jpgCap = 40 * 1024;
    g_jpgBuf = (uint8_t *)malloc(g_jpgCap);
  }

  loadConfig();
  connectWifi();
  g_needRedraw = true;
}

void loop() {
  M5.update();
  handleButtons();
  handleTouch();

  if (g_oskActive) {
    if (g_needRedraw) {
      drawOsk();
      g_needRedraw = false;
    }
    delay(20);
    return;
  }

  if (g_needRedraw) {
    M5.Display.fillScreen(COL_BG);
    switch (g_screen) {
      case SCR_HOME:     drawHome();     break;
      case SCR_STREAM:   drawStream();   break;
      case SCR_SNAPSHOT: drawSnapshot(); break;
      case SCR_CAMCTRL:  drawCamCtrl();  break;
      case SCR_WIFI:     drawWifi();     break;
      case SCR_STATUS:   drawStatus();   break;
      default: break;
    }
    drawFooter();
    g_needRedraw = false;
  }

  // continuous stream refresh when on stream screen
  if (g_screen == SCR_STREAM && g_wifiOk) {
    startStreamLoop();   // non-blocking single-frame attempt
  }

  delay(15);
}

// ============================================================
void loadConfig() {
  prefs.begin("mantis", true);
  cfgSsid  = prefs.getString("ssid",  "Mantis_1_Hotspot");
  cfgPass  = prefs.getString("pass",  "mantis33");
  cfgCamIp = prefs.getString("camip", "192.168.5.1");
  cfgAdmin = prefs.getString("admin", "admin1234");
  prefs.end();
}

void saveConfig() {
  prefs.begin("mantis", false);
  prefs.putString("ssid",  cfgSsid);
  prefs.putString("pass",  cfgPass);
  prefs.putString("camip", cfgCamIp);
  prefs.putString("admin", cfgAdmin);
  prefs.end();
}

void connectWifi() {
  M5.Display.fillScreen(COL_BG);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(2);
  M5.Display.setCursor(20, 90);
  M5.Display.print("Connecting to");
  M5.Display.setCursor(20, 120);
  M5.Display.print(cfgSsid);
  M5.Display.setTextSize(1);

  WiFi.mode(WIFI_STA);
  WiFi.begin(cfgSsid.c_str(), cfgPass.c_str());
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) {
    delay(300);
    M5.Display.print(".");
  }
  g_wifiOk = (WiFi.status() == WL_CONNECTED);
  delay(400);
  g_needRedraw = true;
}

// ============================================================
//  Navigation – capacitive buttons
// ============================================================
void handleButtons() {
  if (millis() - g_lastBtnMs < 220) return;   // debounce

  if (M5.BtnA.wasPressed()) {                 // LEFT / PREV
    g_lastBtnMs = millis();
    if (g_oskActive) {
      // OSK: move cursor left or cancel
      if (g_oskCursor > 0) g_oskCursor--;
      g_needRedraw = true;
      return;
    }
    g_screen = (Screen)((g_screen + SCR_COUNT - 1) % SCR_COUNT);
    stopStream();
    g_needRedraw = true;
  }

  if (M5.BtnC.wasPressed()) {                 // RIGHT / NEXT
    g_lastBtnMs = millis();
    if (g_oskActive) {
      if (g_oskCursor < (int)strlen(g_oskBuf)) g_oskCursor++;
      g_needRedraw = true;
      return;
    }
    g_screen = (Screen)((g_screen + 1) % SCR_COUNT);
    stopStream();
    g_needRedraw = true;
  }

  if (M5.BtnB.wasPressed()) {                 // SELECT / CONFIRM
    g_lastBtnMs = millis();
    if (g_oskActive) {
      // confirm OSK → write back & hide
      if (g_oskTarget) *g_oskTarget = String(g_oskBuf);
      g_oskActive = false;
      g_oskTarget = nullptr;
      saveConfig();
      g_needRedraw = true;
      return;
    }
    // screen-specific select actions
    switch (g_screen) {
      case SCR_HOME:
        g_screen = SCR_STREAM;
        g_needRedraw = true;
        break;
      case SCR_SNAPSHOT:
        fetchSnapshot();
        g_needRedraw = true;
        break;
      case SCR_WIFI:
        // open OSK on SSID by default when select pressed on WiFi screen
        g_oskTarget = &cfgSsid;
        g_oskTitle  = "Edit SSID";
        strncpy(g_oskBuf, cfgSsid.c_str(), sizeof(g_oskBuf) - 1);
        g_oskCursor = strlen(g_oskBuf);
        g_oskActive = true;
        g_needRedraw = true;
        break;
      case SCR_CAMCTRL:
        // toggle LED as a quick action
        g_led = g_led ? 0 : 180;
        httpControl("led", g_led);
        g_needRedraw = true;
        break;
      default: break;
    }
  }
}

// ============================================================
//  Touch handling (OSK keys + on-screen soft buttons)
// ============================================================
void handleTouch() {
  auto t = M5.Touch.getDetail();
  if (!t.wasPressed()) return;

  if (g_oskActive) {
    // simple 10-column QWERTY layout
    // rows at y = 70, 110, 150, 190
    int col = t.x / 32;
    int row = (t.y - 60) / 40;
    if (row < 0 || row > 3 || col < 0 || col > 9) return;

    static const char *rows[4] = {
      "1234567890",
      "qwertyuiop",
      "asdfghjkl-",
      "zxcvbnm._@"
    };
    char ch = rows[row][col];
    if (g_oskShift && ch >= 'a' && ch <= 'z') ch -= 32;

    if (g_oskCursor < (int)sizeof(g_oskBuf) - 1) {
      // insert
      memmove(g_oskBuf + g_oskCursor + 1, g_oskBuf + g_oskCursor,
              strlen(g_oskBuf) - g_oskCursor + 1);
      g_oskBuf[g_oskCursor++] = ch;
    }
    g_needRedraw = true;
    return;
  }

  // soft buttons on WiFi screen
  if (g_screen == SCR_WIFI) {
    // SSID edit zone
    if (t.y > 70 && t.y < 110) {
      g_oskTarget = &cfgSsid;
      g_oskTitle  = "Edit SSID";
      strncpy(g_oskBuf, cfgSsid.c_str(), sizeof(g_oskBuf) - 1);
      g_oskCursor = strlen(g_oskBuf);
      g_oskActive = true;
      g_needRedraw = true;
    }
    // Password edit zone
    else if (t.y > 120 && t.y < 160) {
      g_oskTarget = &cfgPass;
      g_oskTitle  = "Edit Password";
      strncpy(g_oskBuf, cfgPass.c_str(), sizeof(g_oskBuf) - 1);
      g_oskCursor = strlen(g_oskBuf);
      g_oskActive = true;
      g_needRedraw = true;
    }
    // Reconnect button
    else if (t.y > 175 && t.y < 215) {
      connectWifi();
    }
  }

  // soft buttons on Camera Ctrl
  if (g_screen == SCR_CAMCTRL) {
    // quality − / +
    if (t.y > 55 && t.y < 90) {
      if (t.x < 160) { g_quality = constrain(g_quality - 2, 4, 63); httpControl("quality", g_quality); }
      else           { g_quality = constrain(g_quality + 2, 4, 63); httpControl("quality", g_quality); }
      g_needRedraw = true;
    }
    // brightness
    if (t.y > 95 && t.y < 130) {
      if (t.x < 160) { g_bright = constrain(g_bright - 1, -2, 2); httpControl("brightness", g_bright); }
      else           { g_bright = constrain(g_bright + 1, -2, 2); httpControl("brightness", g_bright); }
      g_needRedraw = true;
    }
    // LED
    if (t.y > 135 && t.y < 170) {
      if (t.x < 160) { g_led = constrain(g_led - 40, 0, 255); httpControl("led", g_led); }
      else           { g_led = constrain(g_led + 40, 0, 255); httpControl("led", g_led); }
      g_needRedraw = true;
    }
    // mirror / flip toggles
    if (t.y > 175 && t.y < 210) {
      if (t.x < 160) { g_hmirror = !g_hmirror; httpControl("hmirror", g_hmirror); }
      else           { g_vflip   = !g_vflip;   httpControl("vflip",   g_vflip); }
      g_needRedraw = true;
    }
  }
}

// ============================================================
//  Drawing helpers
// ============================================================
void drawHeader(const char *title) {
  M5.Display.fillRect(0, 0, 320, 28, COL_PANEL);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(8, 8);
  M5.Display.printf("MANTIS  ·  %s", title);
  // wifi indicator
  M5.Display.setCursor(250, 8);
  M5.Display.setTextColor(g_wifiOk ? COL_OK : COL_ALERT);
  M5.Display.print(g_wifiOk ? "WiFi OK" : "NO WiFi");
}

void drawFooter() {
  M5.Display.fillRect(0, 220, 320, 20, COL_PANEL);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(8, 226);
  M5.Display.print("A:Prev   B:Select   C:Next");
  M5.Display.setCursor(230, 226);
  M5.Display.printf("%d/%d", (int)g_screen + 1, (int)SCR_COUNT);
}

void drawHome() {
  drawHeader("Home");
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(3);
  M5.Display.setCursor(40, 55);
  M5.Display.print("MANTIS");
  M5.Display.setTextSize(1);
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(40, 100);
  M5.Display.print("Praying-Mantis CAM Companion");
  M5.Display.setCursor(40, 120);
  M5.Display.printf("Target: %s", cfgCamIp.c_str());
  M5.Display.setCursor(40, 140);
  M5.Display.printf("Hotspot: %s", cfgSsid.c_str());
  M5.Display.setCursor(40, 170);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.print("Press B or C to enter Live Stream");
}

void drawStream() {
  drawHeader("Live Stream");
  if (!g_wifiOk) {
    M5.Display.setTextColor(COL_ALERT);
    M5.Display.setCursor(30, 100);
    M5.Display.print("WiFi not connected");
    return;
  }
  // actual frame is painted by startStreamLoop()
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setCursor(60, 110);
  M5.Display.print("Waiting for frames...");
}

void drawSnapshot() {
  drawHeader("Snapshot");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(30, 80);
  M5.Display.print("Press B (Select) to capture");
  M5.Display.setCursor(30, 100);
  M5.Display.print("a still image from the CAM.");
  M5.Display.setCursor(30, 140);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.print("Image is shown full-screen");
  M5.Display.setCursor(30, 155);
  M5.Display.print("for a few seconds.");
}

void drawCamCtrl() {
  drawHeader("Camera Ctrl");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setTextSize(1);

  auto row = [&](int y, const char *label, int val) {
    M5.Display.fillRoundRect(10, y, 300, 32, 4, COL_PANEL);
    M5.Display.setCursor(20, y + 10);
    M5.Display.printf("%s  %d", label, val);
    M5.Display.setCursor(200, y + 10);
    M5.Display.setTextColor(COL_ACCENT);
    M5.Display.print("-          +");
    M5.Display.setTextColor(COL_TEXT);
  };

  row(55,  "Quality",    g_quality);
  row(95,  "Brightness", g_bright);
  row(135, "LED Flash",  g_led);

  M5.Display.fillRoundRect(10, 175, 145, 32, 4, COL_PANEL);
  M5.Display.setCursor(25, 185);
  M5.Display.printf("Mirror %s", g_hmirror ? "ON" : "off");
  M5.Display.fillRoundRect(165, 175, 145, 32, 4, COL_PANEL);
  M5.Display.setCursor(180, 185);
  M5.Display.printf("Flip %s", g_vflip ? "ON" : "off");
}

void drawWifi() {
  drawHeader("WiFi Setup");
  M5.Display.setTextColor(COL_TEXT);

  M5.Display.fillRoundRect(10, 50, 300, 40, 4, COL_PANEL);
  M5.Display.setCursor(20, 55);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.print("SSID (tap to edit)");
  M5.Display.setCursor(20, 72);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.print(cfgSsid);

  M5.Display.fillRoundRect(10, 100, 300, 40, 4, COL_PANEL);
  M5.Display.setCursor(20, 105);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.print("Password (tap to edit)");
  M5.Display.setCursor(20, 122);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.print(cfgPass);

  M5.Display.fillRoundRect(10, 155, 300, 40, 4, COL_BTN);
  M5.Display.setCursor(90, 170);
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.print("RECONNECT NOW");
}

void drawStatus() {
  drawHeader("Status");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(20, 50);
  M5.Display.printf("WiFi: %s", g_wifiOk ? "Connected" : "Disconnected");
  M5.Display.setCursor(20, 70);
  M5.Display.printf("IP:   %s", WiFi.localIP().toString().c_str());
  M5.Display.setCursor(20, 90);
  M5.Display.printf("RSSI: %d dBm", WiFi.RSSI());
  M5.Display.setCursor(20, 110);
  M5.Display.printf("CAM:  %s", cfgCamIp.c_str());
  M5.Display.setCursor(20, 130);
  M5.Display.printf("Heap: %u KB", ESP.getFreeHeap() / 1024);
  M5.Display.setCursor(20, 150);
  M5.Display.printf("PSRAM:%u KB", ESP.getPsramSize() / 1024);

  // try a quick /status poll
  if (g_wifiOk) {
    JsonDocument doc;
    if (httpGetJson("/status", doc)) {
      M5.Display.setCursor(20, 175);
      M5.Display.printf("CAM fw: %s  sensor: %s",
                        doc["fw"] | "?", doc["sensor"] | "?");
      M5.Display.setCursor(20, 195);
      M5.Display.printf("CAM heap: %u  FPS: %.1f",
                        (unsigned)(doc["heap"] | 0) / 1024,
                        (double)(doc["fps"] | 0.0));
    }
  }
}

void drawOsk() {
  M5.Display.fillScreen(COL_BG);
  M5.Display.fillRect(0, 0, 320, 50, COL_PANEL);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setCursor(10, 8);
  M5.Display.print(g_oskTitle);
  M5.Display.setCursor(10, 28);
  M5.Display.setTextColor(COL_TEXT);
  // show current buffer with cursor
  String shown = String(g_oskBuf);
  M5.Display.print(shown.substring(0, g_oskCursor));
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.print("|");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.print(shown.substring(g_oskCursor));

  // draw keys
  static const char *rows[4] = {
    "1234567890",
    "qwertyuiop",
    "asdfghjkl-",
    "zxcvbnm._@"
  };
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 10; c++) {
      int x = c * 32;
      int y = 60 + r * 40;
      M5.Display.fillRoundRect(x + 1, y + 1, 30, 36, 3, COL_BTN);
      M5.Display.setTextColor(COL_TEXT);
      M5.Display.setCursor(x + 10, y + 12);
      char ch = rows[r][c];
      if (g_oskShift && ch >= 'a' && ch <= 'z') ch -= 32;
      M5.Display.print(ch);
    }
  }
  // hint
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setCursor(10, 225);
  M5.Display.print("B = OK / confirm     A/C = move cursor");
}

// ============================================================
//  Network helpers (talk to the ESP32-CAM)
// ============================================================
bool httpGetJson(const String &path, JsonDocument &doc) {
  HTTPClient http;
  String url = "http://" + cfgCamIp + path;
  http.begin(url);
  http.setTimeout(2500);
  int code = http.GET();
  if (code != 200) {
    http.end();
    return false;
  }
  String body = http.getString();
  http.end();
  return !deserializeJson(doc, body);
}

bool httpControl(const char *var, int val) {
  HTTPClient http;
  String url = "http://" + cfgCamIp + "/control?var=" + String(var) +
               "&val=" + String(val);
  http.begin(url);
  http.setTimeout(2000);
  int code = http.GET();
  http.end();
  return code == 200;
}

bool httpControlStr(const char *var, const char *val) {
  HTTPClient http;
  String url = "http://" + cfgCamIp + "/control?var=" + String(var) +
               "&val=" + String(val);
  http.begin(url);
  http.setTimeout(2000);
  int code = http.GET();
  http.end();
  return code == 200;
}

// JPEG draw callback → push RGB565 straight to the display
int jpegDrawCallback(JPEGDRAW *p) {
  M5.Display.pushImage(p->x, p->y, p->iWidth, p->iHeight, (uint16_t *)p->pPixels);
  return 1;
}

bool fetchSnapshot() {
  if (!g_wifiOk || !g_jpgBuf) return false;
  HTTPClient http;
  String url = "http://" + cfgCamIp + "/snapshot";
  http.begin(url);
  http.setTimeout(6000);
  int code = http.GET();
  if (code != 200) {
    http.end();
    return false;
  }
  int len = http.getSize();
  if (len <= 0 || len > (int)g_jpgCap) {
    // stream into buffer
    WiFiClient *stream = http.getStreamPtr();
    g_jpgLen = 0;
    while (http.connected() && g_jpgLen < g_jpgCap) {
      size_t avail = stream->available();
      if (avail) {
        int n = stream->readBytes(g_jpgBuf + g_jpgLen,
                                  min(avail, g_jpgCap - g_jpgLen));
        g_jpgLen += n;
      } else {
        delay(1);
      }
      if (!http.connected()) break;
    }
  } else {
    g_jpgLen = http.getStream().readBytes(g_jpgBuf, len);
  }
  http.end();

  if (g_jpgLen < 100) return false;

  // decode & show full screen (scaled)
  if (jpeg.openRAM(g_jpgBuf, g_jpgLen, jpegDrawCallback)) {
    jpeg.setPixelType(RGB565_BIG_ENDIAN);
    // scale to fit 320×240 roughly
    int scale = 0;
    if (jpeg.getWidth() > 640) scale = 2;
    else if (jpeg.getWidth() > 320) scale = 1;
    jpeg.setMaxOutputSize(0);   // let it decide
    M5.Display.fillScreen(COL_BG);
    jpeg.decode(0, 30, scale);  // leave header room
    jpeg.close();
    delay(2500);               // show for a moment
  }
  return true;
}

void stopStream() {
  g_streaming = false;
}

// Fetch one MJPEG frame and paint it (best-effort, non-blocking style)
void startStreamLoop() {
  static uint32_t lastAttempt = 0;
  if (millis() - lastAttempt < 120) return;   // ~8 fps ceiling
  lastAttempt = millis();
  if (!g_jpgBuf) return;

  HTTPClient http;
  String url = "http://" + cfgCamIp + ":8081/stream";
  http.begin(url);
  http.setTimeout(3000);
  int code = http.GET();
  if (code != 200) {
    http.end();
    return;
  }

  WiFiClient *stream = http.getStreamPtr();
  // find SOI
  g_jpgLen = 0;
  bool inFrame = false;
  uint32_t t0 = millis();
  while (millis() - t0 < 2500 && g_jpgLen < g_jpgCap) {
    if (!stream->available()) {
      delay(1);
      continue;
    }
    uint8_t b = stream->read();
    if (!inFrame) {
      // look for 0xFF 0xD8
      if (g_jpgLen == 0 && b == 0xFF) {
        g_jpgBuf[g_jpgLen++] = b;
      } else if (g_jpgLen == 1 && b == 0xD8) {
        g_jpgBuf[g_jpgLen++] = b;
        inFrame = true;
      } else {
        g_jpgLen = 0;
      }
    } else {
      g_jpgBuf[g_jpgLen++] = b;
      // look for EOI 0xFF 0xD9
      if (g_jpgLen > 2 &&
          g_jpgBuf[g_jpgLen - 2] == 0xFF &&
          g_jpgBuf[g_jpgLen - 1] == 0xD9) {
        break;
      }
    }
  }
  http.end();

  if (g_jpgLen < 200) return;

  if (jpeg.openRAM(g_jpgBuf, g_jpgLen, jpegDrawCallback)) {
    jpeg.setPixelType(RGB565_BIG_ENDIAN);
    int scale = (jpeg.getWidth() > 320) ? 1 : 0;
    // clear only the content area once
    static bool cleared = false;
    if (!cleared) {
      M5.Display.fillRect(0, 28, 320, 192, COL_BG);
      cleared = true;
    }
    jpeg.decode(0, 28, scale);
    jpeg.close();
  }
}
