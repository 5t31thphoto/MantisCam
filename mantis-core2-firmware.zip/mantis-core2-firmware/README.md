# MANTIS — Praying-Mantis Core2 Companion + ESP32-CAM Fleet

Elegant firmware for **M5Stack Core2** that talks to one or more ESP32-CAM units
running the Universal CAM firmware (SoftAP `Mantis_1_Hotspot` / `mantis33`,
stream on port 8081).

## Features

- **Capacitive navigation**: BtnA = previous, BtnB = select, BtnC = next
- Live MJPEG preview (JPEGDEC + M5Unified)
- Snapshot capture
- On-device camera controls (quality, brightness, LED, mirror, flip) via `/control`
- WiFi credentials editor with **auto-show / auto-hide on-screen keyboard**
- Status page that polls the camera’s `/status` JSON
- Single **merged binary** (bootloader + partitions + app) for easy flashing
- GitHub Actions CI: zip-extractor → build → merge → GitHub Pages (download + web flasher)

## Quick start

1. Push this repo to GitHub and enable **Pages** (source = GitHub Actions).
2. Every push to `main` builds the firmware and publishes the site.
3. Optional: drop a `.zip` in the repo root; the first CI step extracts it
   with overwrite (“add & replace”) before the build — useful for extra assets
   or a `cam/` sub-project that produces `esp32cam-fleet.bin`.

## Local build

```bash
pio run -e m5stack-core2
# produces firmware_merged.bin in the project root
```

## Default camera settings expected by Core2

| Item        | Value                  |
|-------------|------------------------|
| SoftAP SSID | `Mantis_1_Hotspot`     |
| SoftAP pass | `mantis33`             |
| AP IP       | `192.168.5.1`          |
| Stream      | `http://192.168.5.1:8081/stream` |
| Snapshot    | `http://192.168.5.1/snapshot`    |

Change any of these from the Core2 **WiFi Setup** screen; they are stored in NVS.

## Fleet workflow

1. **Website** – flash Core2 + (optionally) ESP32-CAM fleet image.
2. **Core2** – day-to-day stream / snapshot / control / WiFi reconfiguration.
3. **Updates** – always via the website / new CI build (no OTA path).

## License

MIT — use freely for personal or commercial fleets.
