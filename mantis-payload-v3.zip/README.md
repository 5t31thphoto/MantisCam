# MANTIS Core2 v2 — Praying-Mantis Companion + ESP32-CAM Fleet

Elegant firmware for **M5Stack Core2** that talks to ESP32-CAM units
(SoftAP `Mantis_1_Hotspot` / `mantis33`, stream on port 8081).

## What’s new in v2

- **Live Stream REC** — on the Stream screen the middle button is labelled **REC**.  
  Press B to start recording MJPEG frames to `/videos/rec_….mjpeg` (max 30 s).  
  Press B again (or auto-timeout) to stop and close the file.
- **Snapshot → SD** — B (or on-screen button) captures a still and saves it under  
  `/images/snap_….jpg`.
- **Audio Record** — dedicated screen; B starts/stops recording from the Core2  
  microphone to `/audio/rec_….wav` (max 20 s).
- **Audio Play** — lists WAVs in `/audio/`, tap to select, B to play via the  
  built-in speaker.
- SD card folders are created automatically (`images/`, `videos/`, `audio/`).

## Navigation

| Button | Action                          |
|--------|---------------------------------|
| A      | Previous screen                 |
| B      | Select / REC / Play / Confirm   |
| C      | Next screen                     |

On-screen keyboard appears automatically when editing WiFi credentials and hides on B = OK.

## Build

```bash
pio run -e m5stack-core2
# → firmware_merged.bin in project root
```

## Default camera settings

| Item        | Value                          |
|-------------|-------------------------------|
| SoftAP SSID | `Mantis_1_Hotspot`            |
| SoftAP pass | `mantis33`                    |
| AP IP       | `192.168.5.1`                 |
| Stream      | `http://192.168.5.1:8081/stream` |
| Snapshot    | `http://192.168.5.1/snapshot` |

## Fleet workflow

1. Website (GitHub Pages) – flash Core2 + optional ESP32-CAM fleet image.  
2. Core2 – day-to-day stream / REC / snapshot / audio / camera control.  
3. Updates – always via the website / new CI build (no OTA).

## License

MIT
