/*
 * ============================================================
 *  MANTIS Core2 v2 — Elegant Praying-Mantis Companion Firmware
 *  for M5Stack Core2  ↔  ESP32-CAM (SoftAP at 192.168.5.1)
 * ============================================================
 *  Navigation (capacitive buttons):
 *      BtnA (left)  = previous screen / back
 *      BtnB (middle)= select / confirm / REC toggle
 *      BtnC (right) = next screen / forward
 *
 *  Default CAM hotspot:  Mantis_1_Hotspot / mantis33
 *  Stream:               http://192.168.5.1:8081/stream
 *  Snapshot:             http://192.168.5.1/snapshot
 *  Control:              http://192.168.5.1/control?var=…&val=…
 *
 *  SD card:
 *      /images/   — JPEG snapshots
 *      /videos/   — MJPEG recordings
 *      /audio/    — WAV clips from Core2 mic
 */

#include <M5Unified.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <JPEGDEC.h>
#include <SD.h>
#include <SPI.h>

// -------------------- theme palette (mantis) --------------------
static const uint16_t COL_BG       = 0x0A20;
static const uint16_t COL_PANEL    = 0x1A40;
static const uint16_t COL_ACCENT   = 0x5FE0;
static const uint16_t COL_TEXT     = 0xE7FF;
static const uint16_t COL_DIM      = 0x7BEF;
static const uint16_t COL_ALERT    = 0xF800;
static const uint16_t COL_OK       = 0x07E0;
static const uint16_t COL_BTN      = 0x2A60;
static const uint16_t COL_REC      = 0xF800;

// -------------------- screens --------------------
enum Screen : uint8_t {
  SCR_HOME = 0,
  SCR_STREAM,
  SCR_SNAPSHOT,
  SCR_CAMCTRL,
  SCR_WIFI,
  SCR_AUDIO_REC,
  SCR_AUDIO_PLAY,
  SCR_STATUS,
  SCR_COUNT
};
static const char *SCR_NAMES[] = {
  "Home", "Live Stream", "Snapshot", "Camera Ctrl",
  "WiFi Setup", "Audio Rec", "Audio Play", "Status"
};

// -------------------- SD pins (Core2) --------------------
static constexpr int SD_CS   = 4;
static constexpr int SD_SCK  = 18;
static constexpr int SD_MISO = 38;
static constexpr int SD_MOSI = 23;

// -------------------- persistent config --------------------
Preferences prefs;
String cfgSsid   = "Mantis_1_Hotspot";
String cfgPass   = "mantis33";
String cfgCamIp  = "192.168.5.1";
String cfgAdmin  = "admin1234";

// -------------------- runtime state --------------------
Screen  g_screen     = SCR_HOME;
bool    g_wifiOk     = false;
bool    g_sdOk       = false;
bool    g_needRedraw = true;
uint32_t g_lastBtnMs = 0;
JPEGDEC  jpeg;
uint8_t *g_jpgBuf    = nullptr;
size_t   g_jpgCap    = 96 * 1024;
size_t   g_jpgLen    = 0;

// video recording (MJPEG frames → SD)
bool     g_recActive   = false;
uint32_t g_recStartMs  = 0;
static constexpr uint32_t REC_MAX_MS = 30000;   // 30 s max
File     g_recFile;
uint32_t g_recFrames   = 0;

// on-screen keyboard
bool     g_oskActive = false;
String  *g_oskTarget = nullptr;
String   g_oskTitle  = "";
char     g_oskBuf[64] = {0};
int      g_oskCursor = 0;
bool     g_oskShift  = false;

// camera control mirrors
int  g_quality   = 12;
int  g_bright    = 0;
int  g_contrast  = 0;
int  g_led       = 0;
bool g_hmirror   = false;
bool g_vflip     = false;

// audio record / play
bool     g_audioRecActive = false;
uint32_t g_audioRecStart  = 0;
static constexpr uint32_t AUDIO_MAX_MS = 20000;  // 20 s max
static constexpr int AUDIO_SR = 16000;
static constexpr int AUDIO_CHUNK = 512;
int16_t *g_audioBuf = nullptr;
size_t   g_audioBufSamples = 0;
File     g_wavFile;
String   g_audioList[32];
int      g_audioCount = 0;
int      g_audioSel   = 0;
bool     g_audioPlaying = false;

// -------------------- forward decls --------------------
void loadConfig();
void saveConfig();
void connectWifi();
bool initSD();
void ensureDirs();
void drawHeader(const char *title);
void drawFooter();
void drawHome();
void drawStream();
void drawSnapshot();
void drawCamCtrl();
void drawWifi();
void drawAudioRec();
void drawAudioPlay();
void drawStatus();
void drawOsk();
void handleButtons();
void handleTouch();
bool httpGetJson(const String &path, JsonDocument &doc);
bool httpControl(const char *var, int val);
bool fetchSnapshot(bool saveToSd);
void streamFrameTick();
void startVideoRec();
void stopVideoRec();
void startAudioRec();
void stopAudioRec();
void writeWavHeader(File &f, uint32_t dataBytes);
void scanAudioFiles();
void playSelectedAudio();
int  jpegDrawCallback(JPEGDRAW *pDraw);

// ============================================================
void setup() {
  auto cfg = M5.config();
  cfg.serial_baudrate = 115200;
  M5.begin(cfg);
  M5.Display.setRotation(1);
  M5.Display.setBrightness(180);
  M5.Display.fillScreen(COL_BG);

  if (psramFound()) {
    g_jpgBuf = (uint8_t *)ps_malloc(g_jpgCap);
    g_audioBuf = (int16_t *)ps_malloc(AUDIO_SR * 22 * sizeof(int16_t)); // ~20 s + margin
  }
  if (!g_jpgBuf) {
    g_jpgCap = 48 * 1024;
    g_jpgBuf = (uint8_t *)malloc(g_jpgCap);
  }
  if (!g_audioBuf) {
    g_audioBuf = (int16_t *)malloc(AUDIO_SR * 12 * sizeof(int16_t));
  }

  loadConfig();
  g_sdOk = initSD();
  if (g_sdOk) ensureDirs();
  connectWifi();
  g_needRedraw = true;
}

void loop() {
  M5.update();
  handleButtons();
  handleTouch();

  // video record auto-stop
  if (g_recActive && (millis() - g_recStartMs >= REC_MAX_MS)) {
    stopVideoRec();
    g_needRedraw = true;
  }
  // audio record auto-stop
  if (g_audioRecActive && (millis() - g_audioRecStart >= AUDIO_MAX_MS)) {
    stopAudioRec();
    g_needRedraw = true;
  }

  if (g_oskActive) {
    if (g_needRedraw) { drawOsk(); g_needRedraw = false; }
    delay(20);
    return;
  }

  if (g_needRedraw) {
    M5.Display.fillScreen(COL_BG);
    switch (g_screen) {
      case SCR_HOME:       drawHome();       break;
      case SCR_STREAM:     drawStream();     break;
      case SCR_SNAPSHOT:   drawSnapshot();   break;
      case SCR_CAMCTRL:    drawCamCtrl();    break;
      case SCR_WIFI:       drawWifi();       break;
      case SCR_AUDIO_REC:  drawAudioRec();   break;
      case SCR_AUDIO_PLAY: drawAudioPlay();  break;
      case SCR_STATUS:     drawStatus();     break;
      default: break;
    }
    drawFooter();
    g_needRedraw = false;
  }

  if (g_screen == SCR_STREAM && g_wifiOk) {
    streamFrameTick();
  }

  // continuous mic capture while recording
  if (g_audioRecActive && g_audioBuf) {
    static int16_t chunk[AUDIO_CHUNK];
    if (M5.Mic.isEnabled() && M5.Mic.record(chunk, AUDIO_CHUNK, AUDIO_SR)) {
      size_t maxSamp = (AUDIO_SR * 22);
      if (g_audioBufSamples + AUDIO_CHUNK < maxSamp) {
        memcpy(g_audioBuf + g_audioBufSamples, chunk, AUDIO_CHUNK * sizeof(int16_t));
        g_audioBufSamples += AUDIO_CHUNK;
      }
    }
  }

  delay(10);
}

// ============================================================
void loadConfig() {
  prefs.begin("mantis", true);
  cfgSsid  = prefs.getString("ssid",  "Mantis_1_Hotspot");
  cfgPass  = prefs.getString("pass",  "mantis33");
  cfgCamIp = prefs.getString("camip", "192.168.5.1");
  cfgAdmin = prefs.getString("admin", "admin1234");
  prefs.end();
}

void saveConfig() {
  prefs.begin("mantis", false);
  prefs.putString("ssid",  cfgSsid);
  prefs.putString("pass",  cfgPass);
  prefs.putString("camip", cfgCamIp);
  prefs.putString("admin", cfgAdmin);
  prefs.end();
}

bool initSD() {
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  if (!SD.begin(SD_CS, SPI, 25000000)) {
    Serial.println("[SD] init failed");
    return false;
  }
  Serial.println("[SD] OK");
  return true;
}

void ensureDirs() {
  if (!SD.exists("/images")) SD.mkdir("/images");
  if (!SD.exists("/videos")) SD.mkdir("/videos");
  if (!SD.exists("/audio"))  SD.mkdir("/audio");
}

void connectWifi() {
  M5.Display.fillScreen(COL_BG);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(2);
  M5.Display.setCursor(20, 90);
  M5.Display.print("Connecting to");
  M5.Display.setCursor(20, 120);
  M5.Display.print(cfgSsid);
  M5.Display.setTextSize(1);

  WiFi.mode(WIFI_STA);
  WiFi.begin(cfgSsid.c_str(), cfgPass.c_str());
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) {
    delay(300);
    M5.Display.print(".");
  }
  g_wifiOk = (WiFi.status() == WL_CONNECTED);
  delay(300);
  g_needRedraw = true;
}

// ============================================================
void handleButtons() {
  if (millis() - g_lastBtnMs < 220) return;

  if (M5.BtnA.wasPressed()) {
    g_lastBtnMs = millis();
    if (g_oskActive) {
      if (g_oskCursor > 0) g_oskCursor--;
      g_needRedraw = true;
      return;
    }
    if (g_recActive) stopVideoRec();
    if (g_audioRecActive) stopAudioRec();
    if (g_audioPlaying) { M5.Speaker.stop(); g_audioPlaying = false; }
    g_screen = (Screen)((g_screen + SCR_COUNT - 1) % SCR_COUNT);
    g_needRedraw = true;
  }

  if (M5.BtnC.wasPressed()) {
    g_lastBtnMs = millis();
    if (g_oskActive) {
      if (g_oskCursor < (int)strlen(g_oskBuf)) g_oskCursor++;
      g_needRedraw = true;
      return;
    }
    if (g_recActive) stopVideoRec();
    if (g_audioRecActive) stopAudioRec();
    if (g_audioPlaying) { M5.Speaker.stop(); g_audioPlaying = false; }
    g_screen = (Screen)((g_screen + 1) % SCR_COUNT);
    g_needRedraw = true;
  }

  if (M5.BtnB.wasPressed()) {
    g_lastBtnMs = millis();
    if (g_oskActive) {
      if (g_oskTarget) *g_oskTarget = String(g_oskBuf);
      g_oskActive = false;
      g_oskTarget = nullptr;
      saveConfig();
      g_needRedraw = true;
      return;
    }

    switch (g_screen) {
      case SCR_HOME:
        g_screen = SCR_STREAM;
        g_needRedraw = true;
        break;
      case SCR_STREAM:
        // B = REC toggle
        if (g_recActive) stopVideoRec();
        else             startVideoRec();
        g_needRedraw = true;
        break;
      case SCR_SNAPSHOT:
        fetchSnapshot(true);   // capture + save to SD
        g_needRedraw = true;
        break;
      case SCR_WIFI:
        g_oskTarget = &cfgSsid;
        g_oskTitle  = "Edit SSID";
        strncpy(g_oskBuf, cfgSsid.c_str(), sizeof(g_oskBuf) - 1);
        g_oskCursor = strlen(g_oskBuf);
        g_oskActive = true;
        g_needRedraw = true;
        break;
      case SCR_CAMCTRL:
        g_led = g_led ? 0 : 180;
        httpControl("led", g_led);
        g_needRedraw = true;
        break;
      case SCR_AUDIO_REC:
        if (g_audioRecActive) stopAudioRec();
        else                  startAudioRec();
        g_needRedraw = true;
        break;
      case SCR_AUDIO_PLAY:
        playSelectedAudio();
        g_needRedraw = true;
        break;
      default: break;
    }
  }
}

void handleTouch() {
  auto t = M5.Touch.getDetail();
  if (!t.wasPressed()) return;

  if (g_oskActive) {
    int col = t.x / 32;
    int row = (t.y - 60) / 40;
    if (row < 0 || row > 3 || col < 0 || col > 9) return;
    static const char *rows[4] = {
      "1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm._@"
    };
    char ch = rows[row][col];
    if (g_oskShift && ch >= 'a' && ch <= 'z') ch -= 32;
    if (g_oskCursor < (int)sizeof(g_oskBuf) - 1) {
      memmove(g_oskBuf + g_oskCursor + 1, g_oskBuf + g_oskCursor,
              strlen(g_oskBuf) - g_oskCursor + 1);
      g_oskBuf[g_oskCursor++] = ch;
    }
    g_needRedraw = true;
    return;
  }

  if (g_screen == SCR_WIFI) {
    if (t.y > 70 && t.y < 110) {
      g_oskTarget = &cfgSsid; g_oskTitle = "Edit SSID";
      strncpy(g_oskBuf, cfgSsid.c_str(), sizeof(g_oskBuf)-1);
      g_oskCursor = strlen(g_oskBuf); g_oskActive = true; g_needRedraw = true;
    } else if (t.y > 120 && t.y < 160) {
      g_oskTarget = &cfgPass; g_oskTitle = "Edit Password";
      strncpy(g_oskBuf, cfgPass.c_str(), sizeof(g_oskBuf)-1);
      g_oskCursor = strlen(g_oskBuf); g_oskActive = true; g_needRedraw = true;
    } else if (t.y > 175 && t.y < 215) {
      connectWifi();
    }
  }

  if (g_screen == SCR_CAMCTRL) {
    if (t.y > 55 && t.y < 90) {
      if (t.x < 160) { g_quality = constrain(g_quality-2,4,63); httpControl("quality",g_quality); }
      else           { g_quality = constrain(g_quality+2,4,63); httpControl("quality",g_quality); }
      g_needRedraw = true;
    }
    if (t.y > 95 && t.y < 130) {
      if (t.x < 160) { g_bright = constrain(g_bright-1,-2,2); httpControl("brightness",g_bright); }
      else           { g_bright = constrain(g_bright+1,-2,2); httpControl("brightness",g_bright); }
      g_needRedraw = true;
    }
    if (t.y > 135 && t.y < 170) {
      if (t.x < 160) { g_led = constrain(g_led-40,0,255); httpControl("led",g_led); }
      else           { g_led = constrain(g_led+40,0,255); httpControl("led",g_led); }
      g_needRedraw = true;
    }
    if (t.y > 175 && t.y < 210) {
      if (t.x < 160) { g_hmirror = !g_hmirror; httpControl("hmirror", g_hmirror); }
      else           { g_vflip   = !g_vflip;   httpControl("vflip",   g_vflip); }
      g_needRedraw = true;
    }
  }

  if (g_screen == SCR_AUDIO_PLAY) {
    // tap list items
    int idx = (t.y - 50) / 22;
    if (idx >= 0 && idx < g_audioCount) {
      g_audioSel = idx;
      g_needRedraw = true;
    }
  }

  if (g_screen == SCR_SNAPSHOT) {
    // soft button "Save to SD"
    if (t.y > 160 && t.y < 200) {
      fetchSnapshot(true);
      g_needRedraw = true;
    }
  }
}

// ============================================================
void drawHeader(const char *title) {
  M5.Display.fillRect(0, 0, 320, 28, COL_PANEL);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(8, 8);
  M5.Display.printf("MANTIS  ·  %s", title);
  M5.Display.setCursor(220, 8);
  M5.Display.setTextColor(g_wifiOk ? COL_OK : COL_ALERT);
  M5.Display.print(g_wifiOk ? "WiFi" : "NoWiFi");
  M5.Display.setCursor(270, 8);
  M5.Display.setTextColor(g_sdOk ? COL_OK : COL_ALERT);
  M5.Display.print(g_sdOk ? "SD" : "NoSD");
}

void drawFooter() {
  M5.Display.fillRect(0, 220, 320, 20, COL_PANEL);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(6, 226);
  if (g_screen == SCR_STREAM) {
    M5.Display.print("A:Prev   B:REC   C:Next");
  } else if (g_screen == SCR_AUDIO_REC) {
    M5.Display.print("A:Prev   B:Rec/Stop   C:Next");
  } else if (g_screen == SCR_AUDIO_PLAY) {
    M5.Display.print("A:Prev   B:Play   C:Next");
  } else {
    M5.Display.print("A:Prev   B:Select   C:Next");
  }
  M5.Display.setCursor(250, 226);
  M5.Display.printf("%d/%d", (int)g_screen+1, (int)SCR_COUNT);

  // floating "REC" label above B when on stream
  if (g_screen == SCR_STREAM) {
    M5.Display.fillRoundRect(130, 200, 60, 18, 3, g_recActive ? COL_REC : COL_BTN);
    M5.Display.setTextColor(COL_TEXT);
    M5.Display.setCursor(145, 204);
    M5.Display.print(g_recActive ? "STOP" : "REC");
  }
}

void drawHome() {
  drawHeader("Home");
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setTextSize(3);
  M5.Display.setCursor(40, 50);
  M5.Display.print("MANTIS");
  M5.Display.setTextSize(1);
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(40, 95);
  M5.Display.print("Praying-Mantis CAM Companion v2");
  M5.Display.setCursor(40, 115);
  M5.Display.printf("Target: %s", cfgCamIp.c_str());
  M5.Display.setCursor(40, 135);
  M5.Display.printf("Hotspot: %s", cfgSsid.c_str());
  M5.Display.setCursor(40, 160);
  M5.Display.setTextColor(COL_DIM);
  M5.Display.print("B or C → Live Stream  |  SD for media");
}

void drawStream() {
  drawHeader("Live Stream");
  if (!g_wifiOk) {
    M5.Display.setTextColor(COL_ALERT);
    M5.Display.setCursor(30, 100);
    M5.Display.print("WiFi not connected");
    return;
  }
  if (g_recActive) {
    uint32_t sec = (millis() - g_recStartMs) / 1000;
    M5.Display.fillRoundRect(10, 32, 120, 18, 3, COL_REC);
    M5.Display.setTextColor(COL_TEXT);
    M5.Display.setCursor(18, 36);
    M5.Display.printf("REC %02lu:%02lu  f:%lu", sec/60, sec%60, (unsigned long)g_recFrames);
  } else {
    M5.Display.setTextColor(COL_DIM);
    M5.Display.setCursor(60, 110);
    M5.Display.print("Waiting for frames...");
  }
}

void drawSnapshot() {
  drawHeader("Snapshot");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(20, 60);
  M5.Display.print("B = capture + save to SD");
  M5.Display.setCursor(20, 80);
  M5.Display.print("(/images/snap_YYYYMMDD_HHMMSS.jpg)");
  M5.Display.fillRoundRect(40, 160, 240, 36, 6, COL_BTN);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setCursor(80, 172);
  M5.Display.print("TAP = Save Snapshot");
}

void drawCamCtrl() {
  drawHeader("Camera Ctrl");
  M5.Display.setTextColor(COL_TEXT);
  auto row = [&](int y, const char *label, int val) {
    M5.Display.fillRoundRect(10, y, 300, 32, 4, COL_PANEL);
    M5.Display.setCursor(20, y+10);
    M5.Display.printf("%s  %d", label, val);
    M5.Display.setCursor(200, y+10);
    M5.Display.setTextColor(COL_ACCENT);
    M5.Display.print("-          +");
    M5.Display.setTextColor(COL_TEXT);
  };
  row(55,  "Quality",    g_quality);
  row(95,  "Brightness", g_bright);
  row(135, "LED Flash",  g_led);
  M5.Display.fillRoundRect(10, 175, 145, 32, 4, COL_PANEL);
  M5.Display.setCursor(25, 185);
  M5.Display.printf("Mirror %s", g_hmirror ? "ON" : "off");
  M5.Display.fillRoundRect(165, 175, 145, 32, 4, COL_PANEL);
  M5.Display.setCursor(180, 185);
  M5.Display.printf("Flip %s", g_vflip ? "ON" : "off");
}

void drawWifi() {
  drawHeader("WiFi Setup");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.fillRoundRect(10, 50, 300, 40, 4, COL_PANEL);
  M5.Display.setCursor(20, 55); M5.Display.setTextColor(COL_DIM); M5.Display.print("SSID (tap)");
  M5.Display.setCursor(20, 72); M5.Display.setTextColor(COL_ACCENT); M5.Display.print(cfgSsid);
  M5.Display.fillRoundRect(10, 100, 300, 40, 4, COL_PANEL);
  M5.Display.setCursor(20, 105); M5.Display.setTextColor(COL_DIM); M5.Display.print("Password (tap)");
  M5.Display.setCursor(20, 122); M5.Display.setTextColor(COL_ACCENT); M5.Display.print(cfgPass);
  M5.Display.fillRoundRect(10, 155, 300, 40, 4, COL_BTN);
  M5.Display.setCursor(90, 170); M5.Display.setTextColor(COL_TEXT); M5.Display.print("RECONNECT NOW");
}

void drawAudioRec() {
  drawHeader("Audio Rec");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(20, 55);
  M5.Display.print("Core2 microphone → /audio/*.wav");
  M5.Display.setCursor(20, 75);
  M5.Display.printf("Max duration: %d s", (int)(AUDIO_MAX_MS/1000));
  if (g_audioRecActive) {
    uint32_t sec = (millis() - g_audioRecStart) / 1000;
    M5.Display.fillRoundRect(60, 110, 200, 50, 8, COL_REC);
    M5.Display.setTextColor(COL_TEXT);
    M5.Display.setTextSize(2);
    M5.Display.setCursor(90, 125);
    M5.Display.printf("REC %02lu:%02lu", sec/60, sec%60);
    M5.Display.setTextSize(1);
  } else {
    M5.Display.fillRoundRect(60, 110, 200, 50, 8, COL_BTN);
    M5.Display.setTextColor(COL_ACCENT);
    M5.Display.setTextSize(2);
    M5.Display.setCursor(100, 125);
    M5.Display.print("B = REC");
    M5.Display.setTextSize(1);
  }
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setCursor(20, 180);
  M5.Display.print(g_sdOk ? "SD ready" : "NO SD — insert card");
}

void drawAudioPlay() {
  drawHeader("Audio Play");
  if (!g_sdOk) {
    M5.Display.setTextColor(COL_ALERT);
    M5.Display.setCursor(30, 100);
    M5.Display.print("No SD card");
    return;
  }
  scanAudioFiles();
  M5.Display.setTextColor(COL_TEXT);
  if (g_audioCount == 0) {
    M5.Display.setCursor(30, 100);
    M5.Display.print("No recordings in /audio/");
    return;
  }
  for (int i = 0; i < g_audioCount && i < 7; i++) {
    int y = 50 + i * 22;
    if (i == g_audioSel) {
      M5.Display.fillRoundRect(8, y-2, 304, 20, 3, COL_BTN);
      M5.Display.setTextColor(COL_ACCENT);
    } else {
      M5.Display.setTextColor(COL_TEXT);
    }
    M5.Display.setCursor(16, y);
    M5.Display.print(g_audioList[i]);
  }
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setCursor(20, 200);
  M5.Display.print("Tap file · B = Play");
}

void drawStatus() {
  drawHeader("Status");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.setCursor(20, 45);
  M5.Display.printf("WiFi: %s", g_wifiOk ? "OK" : "down");
  M5.Display.setCursor(20, 63);
  M5.Display.printf("IP:   %s", WiFi.localIP().toString().c_str());
  M5.Display.setCursor(20, 81);
  M5.Display.printf("RSSI: %d dBm", WiFi.RSSI());
  M5.Display.setCursor(20, 99);
  M5.Display.printf("SD:   %s", g_sdOk ? "mounted" : "missing");
  M5.Display.setCursor(20, 117);
  M5.Display.printf("Heap: %u KB  PSRAM: %u KB",
                    ESP.getFreeHeap()/1024, ESP.getPsramSize()/1024);
  if (g_wifiOk) {
    JsonDocument doc;
    if (httpGetJson("/status", doc)) {
      M5.Display.setCursor(20, 145);
      M5.Display.printf("CAM fw: %s  %s", doc["fw"]|"?", doc["sensor"]|"?");
      M5.Display.setCursor(20, 163);
      M5.Display.printf("CAM heap: %u  FPS: %.1f",
                        (unsigned)(doc["heap"]|0)/1024, (double)(doc["fps"]|0.0));
    }
  }
}

void drawOsk() {
  M5.Display.fillScreen(COL_BG);
  M5.Display.fillRect(0, 0, 320, 50, COL_PANEL);
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.setCursor(10, 8);
  M5.Display.print(g_oskTitle);
  M5.Display.setCursor(10, 28);
  M5.Display.setTextColor(COL_TEXT);
  String shown = String(g_oskBuf);
  M5.Display.print(shown.substring(0, g_oskCursor));
  M5.Display.setTextColor(COL_ACCENT);
  M5.Display.print("|");
  M5.Display.setTextColor(COL_TEXT);
  M5.Display.print(shown.substring(g_oskCursor));
  static const char *rows[4] = {
    "1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm._@"
  };
  for (int r = 0; r < 4; r++) {
    for (int c = 0; c < 10; c++) {
      int x = c * 32, y = 60 + r * 40;
      M5.Display.fillRoundRect(x+1, y+1, 30, 36, 3, COL_BTN);
      M5.Display.setTextColor(COL_TEXT);
      M5.Display.setCursor(x+10, y+12);
      char ch = rows[r][c];
      if (g_oskShift && ch >= 'a' && ch <= 'z') ch -= 32;
      M5.Display.print(ch);
    }
  }
  M5.Display.setTextColor(COL_DIM);
  M5.Display.setCursor(10, 225);
  M5.Display.print("B = OK     A/C = move cursor");
}

// ============================================================
bool httpGetJson(const String &path, JsonDocument &doc) {
  HTTPClient http;
  http.begin("http://" + cfgCamIp + path);
  http.setTimeout(2500);
  int code = http.GET();
  if (code != 200) { http.end(); return false; }
  String body = http.getString();
  http.end();
  return !deserializeJson(doc, body);
}

bool httpControl(const char *var, int val) {
  HTTPClient http;
  http.begin("http://" + cfgCamIp + "/control?var=" + String(var) + "&val=" + String(val));
  http.setTimeout(2000);
  int code = http.GET();
  http.end();
  return code == 200;
}

int jpegDrawCallback(JPEGDRAW *p) {
  M5.Display.pushImage(p->x, p->y, p->iWidth, p->iHeight, (uint16_t *)p->pPixels);
  return 1;
}

bool fetchSnapshot(bool saveToSd) {
  if (!g_wifiOk || !g_jpgBuf) return false;
  HTTPClient http;
  http.begin("http://" + cfgCamIp + "/snapshot");
  http.setTimeout(6000);
  int code = http.GET();
  if (code != 200) { http.end(); return false; }

  g_jpgLen = 0;
  WiFiClient *stream = http.getStreamPtr();
  uint32_t t0 = millis();
  while (millis() - t0 < 5000 && g_jpgLen < g_jpgCap) {
    size_t avail = stream->available();
    if (avail) {
      int n = stream->readBytes(g_jpgBuf + g_jpgLen, min(avail, g_jpgCap - g_jpgLen));
      g_jpgLen += n;
    } else delay(1);
  }
  http.end();
  if (g_jpgLen < 100) return false;

  // show on screen
  if (jpeg.openRAM(g_jpgBuf, g_jpgLen, jpegDrawCallback)) {
    jpeg.setPixelType(RGB565_BIG_ENDIAN);
    int scale = (jpeg.getWidth() > 320) ? 1 : 0;
    M5.Display.fillRect(0, 28, 320, 192, COL_BG);
    jpeg.decode(0, 28, scale);
    jpeg.close();
  }

  if (saveToSd && g_sdOk) {
    ensureDirs();
    char name[64];
    time_t now = time(nullptr);
    struct tm *tm = localtime(&now);
    // if no RTC, use millis-based name
    if (tm->tm_year < 120) {
      snprintf(name, sizeof(name), "/images/snap_%lu.jpg", (unsigned long)millis());
    } else {
      snprintf(name, sizeof(name), "/images/snap_%04d%02d%02d_%02d%02d%02d.jpg",
               tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
               tm->tm_hour, tm->tm_min, tm->tm_sec);
    }
    File f = SD.open(name, FILE_WRITE);
    if (f) {
      f.write(g_jpgBuf, g_jpgLen);
      f.close();
      Serial.printf("[SD] saved %s (%u bytes)\n", name, (unsigned)g_jpgLen);
    }
  }
  delay(1800);
  return true;
}

void streamFrameTick() {
  static uint32_t last = 0;
  if (millis() - last < 100) return;
  last = millis();
  if (!g_jpgBuf) return;

  HTTPClient http;
  http.begin("http://" + cfgCamIp + ":8081/stream");
  http.setTimeout(2500);
  int code = http.GET();
  if (code != 200) { http.end(); return; }

  WiFiClient *stream = http.getStreamPtr();
  g_jpgLen = 0;
  bool inFrame = false;
  uint32_t t0 = millis();
  while (millis() - t0 < 2000 && g_jpgLen < g_jpgCap) {
    if (!stream->available()) { delay(1); continue; }
    uint8_t b = stream->read();
    if (!inFrame) {
      if (g_jpgLen == 0 && b == 0xFF) g_jpgBuf[g_jpgLen++] = b;
      else if (g_jpgLen == 1 && b == 0xD8) { g_jpgBuf[g_jpgLen++] = b; inFrame = true; }
      else g_jpgLen = 0;
    } else {
      g_jpgBuf[g_jpgLen++] = b;
      if (g_jpgLen > 2 && g_jpgBuf[g_jpgLen-2] == 0xFF && g_jpgBuf[g_jpgLen-1] == 0xD9)
        break;
    }
  }
  http.end();
  if (g_jpgLen < 200) return;

  // paint
  if (jpeg.openRAM(g_jpgBuf, g_jpgLen, jpegDrawCallback)) {
    jpeg.setPixelType(RGB565_BIG_ENDIAN);
    int scale = (jpeg.getWidth() > 320) ? 1 : 0;
    jpeg.decode(0, 28, scale);
    jpeg.close();
  }

  // if recording, append this JPEG frame to the MJPEG file
  if (g_recActive && g_recFile) {
    g_recFile.write(g_jpgBuf, g_jpgLen);
    g_recFrames++;
  }
}

void startVideoRec() {
  if (!g_sdOk || g_recActive) return;
  ensureDirs();
  char name[64];
  snprintf(name, sizeof(name), "/videos/rec_%lu.mjpeg", (unsigned long)millis());
  g_recFile = SD.open(name, FILE_WRITE);
  if (!g_recFile) {
    Serial.println("[REC] open failed");
    return;
  }
  g_recActive  = true;
  g_recStartMs = millis();
  g_recFrames  = 0;
  Serial.printf("[REC] started %s\n", name);
}

void stopVideoRec() {
  if (!g_recActive) return;
  g_recActive = false;
  if (g_recFile) {
    g_recFile.close();
    Serial.printf("[REC] stopped, %lu frames\n", (unsigned long)g_recFrames);
  }
}

// -------------------- audio --------------------
void writeWavHeader(File &f, uint32_t dataBytes) {
  uint32_t sampleRate = AUDIO_SR;
  uint16_t channels = 1;
  uint16_t bits = 16;
  uint32_t byteRate = sampleRate * channels * bits / 8;
  uint16_t blockAlign = channels * bits / 8;
  uint32_t chunkSize = 36 + dataBytes;
  f.write((const uint8_t *)"RIFF", 4);
  f.write((uint8_t *)&chunkSize, 4);
  f.write((const uint8_t *)"WAVE", 4);
  f.write((const uint8_t *)"fmt ", 4);
  uint32_t sub1 = 16; f.write((uint8_t *)&sub1, 4);
  uint16_t fmt = 1; f.write((uint8_t *)&fmt, 2);
  f.write((uint8_t *)&channels, 2);
  f.write((uint8_t *)&sampleRate, 4);
  f.write((uint8_t *)&byteRate, 4);
  f.write((uint8_t *)&blockAlign, 2);
  f.write((uint8_t *)&bits, 2);
  f.write((const uint8_t *)"data", 4);
  f.write((uint8_t *)&dataBytes, 4);
}

void startAudioRec() {
  if (!g_sdOk || !g_audioBuf || g_audioRecActive) return;
  // mic & speaker can't run together
  M5.Speaker.end();
  M5.Mic.begin();
  g_audioBufSamples = 0;
  g_audioRecActive  = true;
  g_audioRecStart   = millis();
  Serial.println("[AUDIO] rec start");
}

void stopAudioRec() {
  if (!g_audioRecActive) return;
  g_audioRecActive = false;
  M5.Mic.end();
  M5.Speaker.begin();

  if (!g_sdOk || g_audioBufSamples == 0) return;
  ensureDirs();
  char name[64];
  snprintf(name, sizeof(name), "/audio/rec_%lu.wav", (unsigned long)millis());
  File f = SD.open(name, FILE_WRITE);
  if (!f) { Serial.println("[AUDIO] open fail"); return; }
  uint32_t dataBytes = g_audioBufSamples * sizeof(int16_t);
  writeWavHeader(f, dataBytes);
  f.write((uint8_t *)g_audioBuf, dataBytes);
  f.close();
  Serial.printf("[AUDIO] saved %s (%u samples)\n", name, (unsigned)g_audioBufSamples);
}

void scanAudioFiles() {
  g_audioCount = 0;
  if (!g_sdOk) return;
  File root = SD.open("/audio");
  if (!root) return;
  File e = root.openNextFile();
  while (e && g_audioCount < 32) {
    if (!e.isDirectory()) {
      String n = e.name();
      if (n.endsWith(".wav") || n.endsWith(".WAV")) {
        // strip path if present
        int slash = n.lastIndexOf('/');
        g_audioList[g_audioCount++] = (slash >= 0) ? n.substring(slash+1) : n;
      }
    }
    e = root.openNextFile();
  }
  root.close();
}

void playSelectedAudio() {
  if (!g_sdOk || g_audioCount == 0 || g_audioSel >= g_audioCount) return;
  if (g_audioPlaying) {
    M5.Speaker.stop();
    g_audioPlaying = false;
    return;
  }
  String path = "/audio/" + g_audioList[g_audioSel];
  File f = SD.open(path);
  if (!f) return;
  // skip 44-byte WAV header, play raw PCM
  f.seek(44);
  size_t remain = f.size() - 44;
  size_t toRead = min(remain, (size_t)(AUDIO_SR * 22 * sizeof(int16_t)));
  if (!g_audioBuf) { f.close(); return; }
  size_t got = f.read((uint8_t *)g_audioBuf, toRead);
  f.close();
  M5.Mic.end();
  M5.Speaker.begin();
  M5.Speaker.setVolume(180);
  M5.Speaker.playRaw(g_audioBuf, got / sizeof(int16_t), AUDIO_SR, false);
  g_audioPlaying = true;
  Serial.printf("[AUDIO] playing %s\n", path.c_str());
}
